/* Background music provided for this project. Interview audio always takes priority. */
(() => {
  'use strict';
  const audio = document.querySelector('#background-music');
  const toggle = document.querySelector('#music-toggle');
  const label = document.querySelector('#music-label');
  const slider = document.querySelector('#music-volume');
  const dialog = document.querySelector('#interview-dialog');
  const key = 'shanhehuixin-music-v1';
  // Enabled is the reader's preference, independent of browser autoplay permission.
  let enabled = true, volume = 18, failed = false, needsGesture = false;
  let revision = 0, fadeFrame = 0, pending = false, buffering = false;
  try {
    const saved = JSON.parse(localStorage.getItem(key) || '{}');
    if (typeof saved.enabled === 'boolean') enabled = saved.enabled;
    if (Number.isFinite(saved.volume)) volume = Math.max(0, Math.min(100, saved.volume));
  } catch { /* Audio remains usable when storage is unavailable. */ }
  slider.value = volume;
  audio.volume = 0;
  function persist() {
    try { localStorage.setItem(key, JSON.stringify({ enabled, volume })); } catch {}
  }
  function allowed() {
    return enabled && volume > 0 && !document.hidden && !dialog.open;
  }
  function update() {
    const state = !enabled ? '音乐已关' : failed ? '音乐异常' : volume === 0 ? '音乐静音' : dialog.open ? '音乐暂歇' : pending || buffering ? '音乐载入' : audio.paused ? '音乐已开' : '音乐轻伴';
    label.textContent = state;
    toggle.setAttribute('aria-pressed', String(enabled));
    toggle.setAttribute('aria-label', enabled ? '关闭背景音乐' : '开启背景音乐');
    toggle.title = !enabled ? '背景音乐已关闭，点击开启' : failed ? '音乐暂时无法加载，可关闭后重新开启' : dialog.open ? '视频关闭后，音乐会轻声继续' : needsGesture ? '音乐已开启，首次点击或触摸页面后轻声播放；点击此处关闭' : '背景音乐，可随时关闭';
    slider.setAttribute('aria-valuetext', `${volume}%`);
    document.querySelector('.music-controls').dataset.state = state;
  }
  function stop() {
    revision++;
    cancelAnimationFrame(fadeFrame);
    pending = false; buffering = false;
    audio.pause();
    audio.volume = 0;
    update();
  }
  function fadeIn(token) {
    cancelAnimationFrame(fadeFrame);
    const start = performance.now(), from = audio.volume;
    function frame(now) {
      if (token !== revision || !allowed()) return;
      const progress = Math.max(0, Math.min(1, (now - start) / 1400));
      audio.volume = from + (volume / 100 - from) * (1 - (1 - progress) ** 2);
      if (progress < 1) fadeFrame = requestAnimationFrame(frame);
    }
    fadeFrame = requestAnimationFrame(frame);
  }
  function sync() {
    if (!allowed()) { stop(); return; }
    if (!audio.paused || pending) { update(); return; }
    const token = ++revision;
    pending = true; failed = false; needsGesture = false;
    // Request audible playback at a quiet volume, then fade in. A zero-volume
    // autoplay attempt could appear successful yet be paused when made audible.
    audio.volume = Math.min(volume / 100, 0.02);
    update();
    audio.play().then(() => {
      if (token !== revision) { if (!allowed()) audio.pause(); return; }
      pending = false;
      if (!allowed()) { stop(); return; }
      update(); fadeIn(token);
    }).catch(error => {
      if (token !== revision) return;
      pending = false;
      if (error.name === 'AbortError') { update(); return; }
      buffering = false;
      if (error.name === 'NotAllowedError') needsGesture = true;
      else failed = true;
      update();
    });
  }
  toggle.addEventListener('click', () => {
    enabled = !enabled;
    if (enabled && failed) { failed = false; audio.load(); }
    if (enabled && volume === 0) { volume = 18; slider.value = volume; }
    persist(); sync();
  });
  slider.addEventListener('input', () => {
    volume = Number(slider.value); enabled = volume > 0;
    cancelAnimationFrame(fadeFrame);
    if (!audio.paused) audio.volume = volume / 100;
    persist(); sync();
  });
  function firstGesture(event) {
    if (!event.isTrusted || !allowed() || !audio.paused || pending || event.target.closest?.('.music-controls, [data-interview], #interview-dialog')) return;
    if (event.type === 'keydown' && (event.ctrlKey || event.metaKey || event.altKey || ['Escape', 'Shift', 'Control', 'Alt', 'Meta'].includes(event.key))) return;
    sync();
  }
  document.addEventListener('click', firstGesture);
  document.addEventListener('touchend', firstGesture, { passive: true });
  document.addEventListener('keydown', firstGesture);
  // Explicit pre-play hook prevents even a brief overlap with foreground speech.
  window.addEventListener('interview-opening', stop);
  new MutationObserver(sync).observe(dialog, { attributes: true, attributeFilter: ['open'] });
  document.querySelector('#interview-player').addEventListener('play', stop);
  document.addEventListener('visibilitychange', sync);
  window.addEventListener('pagehide', stop);
  window.addEventListener('pageshow', sync);
  audio.addEventListener('error', () => { stop(); failed = true; update(); });
  audio.addEventListener('waiting', () => { if (allowed()) { buffering = true; update(); } });
  audio.addEventListener('playing', () => {
    if (!allowed()) { stop(); return; }
    buffering = false; update();
  });
  // Try immediately. If browser policy blocks autoplay, ordinary page interaction
  // retries it; the reader never has to find and press an enable-music button.
  sync();
})();
